/* @ds-bundle: {"format":4,"namespace":"LearningElementsDesignSystem_87aa9b","components":[{"name":"Button","sourcePath":"components/button/Button.jsx"},{"name":"Card","sourcePath":"components/card/Card.jsx"},{"name":"ProgressBar","sourcePath":"components/progress/ProgressBar.jsx"},{"name":"Tabs","sourcePath":"components/tabs/Tabs.jsx"}],"sourceHashes":{"components/button/Button.jsx":"ab347eb94ae3","components/card/Card.jsx":"e9629a053e8b","components/progress/ProgressBar.jsx":"bf0c7a37310e","components/tabs/Tabs.jsx":"6c4f063c4042"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.LearningElementsDesignSystem_87aa9b = window.LearningElementsDesignSystem_87aa9b || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/button/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Button({
  children,
  variant = 'primary',
  size = 'md',
  disabled = false,
  onClick,
  ...props
}) {
  const baseStyles = {
    fontFamily: 'var(--font-sans)',
    fontWeight: 600,
    border: 'none',
    borderRadius: 'var(--radius-md)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    transition: 'all var(--transition-base)',
    textTransform: 'uppercase',
    fontSize: '0.9rem',
    opacity: disabled ? 0.5 : 1,
    ...props.style
  };
  const variants = {
    primary: {
      backgroundColor: 'var(--color-blue-primary)',
      color: 'var(--color-white)'
    },
    secondary: {
      backgroundColor: 'transparent',
      border: '1px solid var(--color-blue-primary)',
      color: 'var(--color-blue-primary)'
    },
    action: {
      backgroundColor: 'var(--color-orange-primary)',
      color: 'var(--color-white)'
    },
    ghost: {
      backgroundColor: 'transparent',
      color: 'var(--color-blue-primary)'
    }
  };
  const sizes = {
    sm: {
      padding: '8px 16px',
      fontSize: '0.8rem'
    },
    md: {
      padding: '12px 24px'
    },
    lg: {
      padding: '16px 32px',
      fontSize: '1rem'
    }
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    style: {
      ...baseStyles,
      ...variants[variant],
      ...sizes[size]
    },
    disabled: disabled,
    onClick: onClick
  }, props), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/button/Button.jsx", error: String((e && e.message) || e) }); }

// components/card/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Card({
  children,
  variant = 'default',
  ...props
}) {
  const styles = {
    backgroundColor: 'var(--color-white)',
    borderRadius: 'var(--radius-lg)',
    boxShadow: 'var(--shadow-md)',
    padding: 'var(--spacing-6)',
    border: variant === 'outlined' ? '1px solid var(--border-default)' : 'none',
    ...props.style
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    style: styles
  }, props), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/card/Card.jsx", error: String((e && e.message) || e) }); }

// components/progress/ProgressBar.jsx
try { (() => {
function ProgressBar({
  value = 0,
  max = 100,
  label,
  ...props
}) {
  const percentage = value / max * 100;
  return /*#__PURE__*/React.createElement("div", {
    style: props.style
  }, label && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--font-size-sm)',
      fontWeight: 600,
      color: 'var(--color-text-secondary)',
      marginBottom: 'var(--spacing-2)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      height: '10px',
      backgroundColor: 'rgba(255,255,255,0.2)',
      borderRadius: 'var(--radius-lg)',
      overflow: 'hidden',
      boxShadow: 'inset 0 1px 3px rgba(0,0,0,0.1)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: `${percentage}%`,
      height: '100%',
      backgroundColor: 'var(--color-orange-primary)',
      transition: 'width var(--transition-base)',
      borderRadius: 'var(--radius-lg)'
    }
  })));
}
Object.assign(__ds_scope, { ProgressBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/progress/ProgressBar.jsx", error: String((e && e.message) || e) }); }

// components/tabs/Tabs.jsx
try { (() => {
const {
  useState
} = React;
function Tabs({
  items,
  defaultActive = 0,
  onChange,
  ...props
}) {
  const [active, setActive] = useState(defaultActive);
  const handleChange = index => {
    setActive(index);
    onChange?.(index);
  };
  return /*#__PURE__*/React.createElement("div", {
    style: props.style
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      borderBottom: '2px solid var(--color-blue-secondary)',
      marginBottom: 'var(--spacing-6)',
      gap: 'var(--spacing-2)'
    }
  }, items.map((item, i) => /*#__PURE__*/React.createElement("button", {
    key: i,
    onClick: () => handleChange(i),
    style: {
      padding: 'var(--spacing-4)',
      border: 'none',
      backgroundColor: active === i ? '#f0f8ff' : 'transparent',
      color: active === i ? 'var(--color-blue-primary)' : 'var(--color-blue-secondary)',
      borderBottom: active === i ? '3px solid var(--color-orange-primary)' : '3px solid transparent',
      fontWeight: active === i ? 700 : 600,
      cursor: 'pointer',
      transition: 'all var(--transition-base)',
      fontSize: '0.9em'
    }
  }, item.label))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--spacing-6)',
      backgroundColor: 'var(--color-white)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-sm)'
    }
  }, items[active]?.content));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/tabs/Tabs.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.ProgressBar = __ds_scope.ProgressBar;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
