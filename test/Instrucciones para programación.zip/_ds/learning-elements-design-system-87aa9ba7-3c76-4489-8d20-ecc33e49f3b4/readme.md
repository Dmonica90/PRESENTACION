# Learning Elements Design System

A comprehensive design system for **Learning Elements**, specializing in visual and multimedia learning experience design (LXD) for corporate environments. This system powers the visual language for interactive courses, infographics, videos, banners, and custom multimedia content.

## Project Context

**Company:** Learning Elements  
**Specialization:** Learning Experience Design (LXD) for corporate training  
**Primary Product:** GS1 Burnout & Wellbeing Course – a comprehensive online learning module for workplace burnout prevention and employee wellness

## Source Materials

- **Codebase:** `CursoCRE_GS1/` – Full course implementation (HTML/CSS/JS SCORM-compliant learning module)
- **Fonts:** Montserrat family (9 weights: Thin through Black)
- **Logos:** GS1 brand marks (blue and white variants)
- **Assets:** Course imagery, infographics, and reference materials from the GS1 Burnout course

## Visual Foundations

### Color Philosophy
The system uses a **structured, professional palette** balanced for corporate training environments:

- **Primary Brand Colors:** Deep blue (#22335E) for authority and trust; vibrant orange (#EC633C) for action, progress, and engagement
- **Secondary Palette:** Sky blue, teal, and muted accent colors (pink, purple, yellow, green) for visual hierarchy, feedback states, and interactive elements
- **Neutral Foundation:** Carefully curated grays from #F4F4F4 (light backgrounds) to #333333 (primary text) supporting readability and visual clarity
- **Semantic Colors:** Green for success, red for errors, yellow for warnings, cyan for information – standard accessibility conventions

**Design Intent:** Colors are used strategically in learning modules to guide attention, signal interactive elements, and reinforce emotional tone. Orange emphasizes progress and next steps; blue provides calm authority. The palette avoids over-saturation, maintaining focus on content.

### Typography System
**Primary Typeface:** Montserrat (sans-serif, 9 weights)  
**Usage:** All body text, headings, UI elements, and interface chrome

**Type Hierarchy:**
- **Display/H1:** 2.25rem, weight 800 – Course titles, major section headers
- **Heading/H2:** 1.875rem, weight 800 – Unit titles and major section breaks
- **Subheading/H3:** 1.5rem, weight 600 – Content sections, interactive prompts
- **Body (Large):** 1.125rem, weight 400 – Primary instructional text, readable at a distance
- **Body (Standard):** 1rem, weight 400 – Standard paragraph, quiz questions, labels
- **Body (Small):** 0.875rem, weight 400 – Supplementary text, metadata
- **Body (XS):** 0.75rem, weight 400 – Captions, timestamps, footer info

Line-height consistently set to 1.5–1.75 (relaxed) to maximize readability in instructional contexts. Font-display: swap ensures text renders immediately, then swaps to Montserrat once loaded.

### Spacing & Layout
- **Grid basis:** 4px (--spacing-1); multiples create coherent 16px base unit (--spacing-4)
- **Content padding:** 20px (mobile) to 32px (desktop); enforced via CSS custom properties
- **Card/component gaps:** 16px (standard); 24px (section breaks)
- **Max width:** 1000px – prevents excessive line lengths on ultra-wide displays
- **Vertical rhythm:** Consistently spaced headers, paragraphs, and interactive sections using gap-based flexbox layouts

### Visual Motifs & Effects

**Backgrounds:**
- Solid white (#FFFFFF) primary; light gray (#F4F4F4) for secondary surfaces and sidebars
- Full-bleed course imagery (photography) on splash screens and unit intros – warm, professional corporate photography
- No gradients, no heavy patterns – emphasis on clarity and legibility

**Hover & Interactive States:**
- Opacity shifts (0.85–1.0) for buttons and links – subtle, not jarring
- Color transitions to darker shades (blue→darker blue; orange→orange-hover) for primary CTAs
- No scale transforms on buttons; minimal visual disruption maintains focus on learning content
- Scroll indicators and progress bars use color transitions

**Shadows:**
- Minimal shadow system: SM (0 1px 2px) for subtle elevation; MD/LG for cards and modals
- Avoid heavy drop shadows; preference for thin borders (#E0E0E0) to define boundaries

**Corners:**
- Medium radius (0.5rem–1rem) for cards, buttons, and input fields – modern but not playful
- Full pill-radius (9999px) reserved for badges and small accent elements

**Animation & Transitions:**
- Easing: cubic-bezier(0.25, 0.8, 0.25, 1) for interactive elements; ease-in-out for larger transitions
- Duration: 0.15–0.3s for interactions (snappy); 0.6s for slide transitions (deliberate pacing)
- Fade-in (opacity 0→1) for content reveals; slide-up (translate Y) for progressive disclosure
- No bounces; no infinite animations except subtle pulse effects on call-to-action indicators
- Progress bars animate smoothly as learners progress; scroll indicators pulse gently to guide attention

**Borders:**
- 1px solid #E0E0E0 for component boundaries
- 2px solid colors only for active states (tab underlines, progress bars)
- No decorative borders; every border serves functional clarity

### Tone & Interaction Language

The course language is **professional, supportive, and direct:**

- **You/We tone:** "You have completed this module" rather than "This module has been completed"
- **Action-oriented verbs:** "Begin," "Explore," "Submit," "Next" – clear directives
- **Encouraging language:** Progress is celebrated; mistakes are framed as learning opportunities
- **No contractions in formal sections** (course headers, quiz instructions); contractions acceptable in conversational UI
- **Spanish primary** (course is bilingual; see course copy); English available as secondary
- **No emoji** in formal content; limited to supplementary motivational graphics

## Content Fundamentals

**Copy Characteristics:**
- Instructional text is concise and task-focused (under 150 words per section)
- Quiz questions are unambiguous; answer options are similarly weighted in length
- Progress language is transparent ("3 of 5 sections complete") rather than hidden
- Burnout/wellbeing vocabulary is clinical but accessible; terms are defined on first use
- Section titles follow noun-based pattern: "Understanding Burnout," "Building Resilience," "Action Planning"

**Formatting Conventions:**
- Headings are sentence-cased (not title-cased)
- Lists use bullets for non-sequential items; numbered steps for procedural content
- Emphasis via bold or color; italic reserved for citations/video titles
- Code/commands do not appear (not a technical course)

## Iconography

**Approach:** Minimal, purposeful icon usage; icons are supporting visuals, never primary content.

**Sources:**
- **Custom course icons:** Unique SVG icons designed for the GS1 Burnout course (bullet, dialogue, scroll, PDF, play, pause, etc.) – located in `CursoCRE_GS1/img/`
- **No icon font:** Icons are inline SVG or PNG, allowing per-context styling (color, size)
- **Interaction hints:** Small icons (bullet, dialogue bubble, scroll arrow) embedded in course content to signal interactivity
- **Navigation:** Simple arrow icons and menu glyphs; no decorative or skeuomorphic icons

**Icon Style:** Geometric, 2–3px stroke weight; minimalist lines. No filled shapes except for emphasis (e.g., bullet points). Icons are monochromatic (matching text color or using brand orange for CTAs).

## Components

Core reusable UI primitives built from the token system and visual foundations:

**Inventory:**
- **Button** – Primary (blue), secondary (transparent), action (orange), and ghost states; multiple sizes
- **Card** – Elevated container with shadow or outline variant; consistent padding and border-radius
- **Tabs** – Tab navigation with underline-activated style; blue active state with orange indicator
- **ProgressBar** – Horizontal track with orange fill; optional label; smooth transitions

**Additional UI Elements (implemented in UI kit, available for reuse):**
- Navigation bar – Blue header with white text, orange progress indicator, left/right navigation buttons
- Video player – Custom play button (orange) overlaid on full-bleed course imagery; fullscreen overlay
- Download button – Gradient blue-to-teal with shimmer effect; icon + text
- Modal/Overlay – Semi-transparent black backdrop; white container with consistent padding
- Scroll indicator – Orange circular button with animated down-arrow; appears when content overflows

All components use Montserrat typography and token colors. No third-party UI libraries; components are framework-agnostic and styled via CSS custom properties.

## UI Kit: GS1 Burnout & Wellbeing Course

**Product Type:** Corporate eLearning module (SCORM-compliant)  
**Platforms:** Desktop (1920×1080 optimized); mobile responsive  
**Key Screens:**
1. Splash/intro screen with course title and "Begin" CTA
2. Navigation guide modal
3. Main content slides (video, text, infographics, interactive quizzes)
4. Quiz screens with multiple-choice and open-ended questions
5. Progress summary and module completion screen

**Features:**
- Full-screen navigation with progress tracking
- Scrollable content areas with custom scrollbar styling (blue track, orange thumb)
- Interactive video embeds and infographics
- Download buttons for supplementary materials (PDFs)
- Dropdown module menu for navigation between units
- Responsive design; reflow on mobile without losing information hierarchy

## File Structure

```
learning-elements-design-system/
├── styles.css                      (root entry; imports all tokens)
├── tokens/
│   ├── fonts.css                   (@font-face declarations + size/weight scales)
│   ├── colors.css                  (color custom properties + semantic aliases)
│   ├── spacing.css                 (8px baseline scale + layout aliases)
│   └── effects.css                 (shadows, radii, transitions, keyframes)
├── assets/
│   ├── fonts/                      (Montserrat .woff2 files)
│   ├── logos/                      (GS1 blue and white variants)
│   └── images/                     (brand reference imagery)
├── guidelines/                     (foundation specimen cards)
│   ├── colors-primary.html
│   ├── colors-secondary.html
│   ├── colors-semantic.html
│   ├── type-headings.html
│   ├── type-body.html
│   ├── type-weights.html
│   ├── spacing-scale.html
│   ├── brand-logo.html
│   ├── effects-shadows.html
│   └── effects-radius.html
├── components/                     (reusable UI primitives)
└── ui_kits/                        (full product screens)
    └── gs1-course/

```

## Usage

Consumers of this design system:
1. Link the global `styles.css` in their HTML `<head>`
2. Reference token custom properties (e.g., `color: var(--color-blue-primary)`, `gap: var(--spacing-4)`)
3. Import React/JSX components from the compiled bundle (`_ds_bundle.js`)
4. Optionally download full-page UI kit screens for reference or adaptation

## Intentional Decisions

- **No icon font:** Icons are context-sensitive; inline SVG/PNG allows per-use color and sizing without font overhead.
- **Minimal shadows:** Corporate eLearning benefits from flat clarity; shadows are used sparingly for elevation only.
- **No animations by default:** Animations are opt-in and motion-aware (respects `prefers-reduced-motion`).
- **Spanish-first labeling:** Course is primarily Spanish; English available but not primary.
- **Custom scrollbar styling:** Full control over scrollbar color (blue→orange on hover) improves brand recognition and accessibility.

## Next Steps & Iteration

This design system is ready for:
- **Component authoring** – JSX/TSX implementations of all button, tab, modal, and navigation primitives
- **UI kit screens** – Full-page recreations of key course templates for reuse across new modules
- **Template decks** – Slide deck templates for corporate presentations using brand guidelines
- **Accessibility review** – WCAG 2.1 AA conformance for color contrast and interactive states

---

**Last updated:** August 2026  
**Maintained by:** Learning Elements Design Team
